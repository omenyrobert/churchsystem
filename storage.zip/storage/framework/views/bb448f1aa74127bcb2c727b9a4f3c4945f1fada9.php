<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
    <title>Church System</title>
</head>

<body>
    <div class="container-fluid" style="background-color: #bbd0d750; height: 120vh;">
        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="d-flex">
            <div class="col-md-2">
                <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-md-10">
                
                <div class="bg-white p-3 mt-2 shadow overflow-auto" style="border-radius: 15px; height: 100vh;">

                    <h3 style="color: #008ad3; ">members</h3>
                    <a href="<?php echo e(url('/members')); ?>" class="text-decoration-none btn btn-primary">Back</a>
                    <div class="row mt-5 p-1">
                        <div class="col-md-6">
                            <div class="m-4 bg-light rounded p-2 shadow border d-flex">
                                <div style="width: 60%;">
                                    <img src="<?php echo e(!is_null($member?->photo) ? asset($member?->photo) : asset('upload/user/placeholder.png')); ?>"
                                        style="border-radius: 5px; width: 200px; height: 200px; object-fit: cover; border-radius: 100%;">


                                </div>
                                <div>
                                    <h3 style="color: #008ad3; "> <?php echo e($member->full_name); ?></h3>
                                    
                                    <p class=""> <?php echo e($member->date_of_birth); ?> - <span class="text-primary"><?php echo e(\Carbon\Carbon::parse($member->date_of_birth)->age); ?> Yrs<span></p>
                                    <div class="d-flex mt-2">
                                        <p class="text-primary"><?php echo e($member->contact1); ?></p>
                                        <p class="text-primary">&nbsp;<?php echo e($member->contact2); ?></p>
                                    </div>

                                </div>

                            </div>
                            <div class="m-4">

                                <?php $__currentLoopData = $member?->ministries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex"><?php echo e($position?->ministry->ministry); ?> <p style="color: #008ad3; margin-left: 10px;"> <?php echo e($position?->position->position); ?></p></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            
                            <div class="m-4">
                                <label>Place of Residence</label><br />
                                <p class="text-primary"><?php echo e($member->place_of_residence); ?></p>

                            </div>

                            <div class="m-4">
                                <label>Contract</label><br />
                                <p class="text-primary"><?php echo e($member->date_of_birth); ?></p>

                            </div>
                            <div class="m-4">
                                <label>Spouse</label><br />
                                <p class="text-primary"> <?php echo e($member->spouse_name); ?></p>
                                <p class="text-primary"> <?php echo e($member->spouse_contact); ?></p>
                            </div>


                        </div>
                        <div class="col-md-6">
                            <div class="m-4">
                                <label>Job</label><br />
                                <p class="text-primary"> <?php echo e($member->job); ?></p>
                            </div>

                            <div class="m-4">
                                <label>Father</label><br />
                                <p class="text-primary"><?php echo e($member->fathers_name); ?></p>
                                <p class="text-primary"><?php echo e($member->Fathers_contact); ?></p>
                            </div>

                            <div class="m-4">
                                <label>Mothers</label><br />
                                <p class="text-primary"> <?php echo e($member->mothers_name); ?></p>
                                <p class="text-primary"> <?php echo e($member->mothers_contact); ?></p>
                            </div>




                        </div>

                    </div>
                    </form>



                </div>

            </div>

        </div>

    </div>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <!-- Option 2: Separate Popper and Bootstrap JS -->

</body>

</html>
<?php /**PATH /Users/projectcode/Sites/churchsystem/resources/views/members/show.blade.php ENDPATH**/ ?>