
<?php

$all_incomes = \App\Models\Incomes::sum('income');  
                                      
$all_expense = \App\Models\Expenses::sum('expense');  
?>


<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
    <title>Church System</title>
    <style>
        .tab-font {
            font-size: 13px;
        }
    </style>
</head>

<body>
    <div class="container-fluid" style="background-color: #bbd0d750; height: 120vh;">
        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="d-flex">
            <div class="col-md-2">
                <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-md-10">
                
                <div class="bg-white p-3 mt-2 shadow overflow-auto" style="border-radius: 15px; height: 80vh;">
                    <div class="d-flex" style="justify-content: space-between">

                        <?php if($message = Session::get('success')): ?>
                            <div class="alert alert-success">
                                <p><?php echo e($message); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <strong>Whoops!</strong> There were some problems with your
                            input.<br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-md-6">
                            <h3 style="color: #008ad3; ">Report</h3>
                        </div>
                        <div class="col-md-6">
                            <form action="<?php echo e(route('report.print')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php
                                    $json_incomes = json_encode($incomes);
                                    $json_expenses = json_encode($expenses);
                                ?>
                                <input type="hidden" value="<?php echo e($json_incomes); ?>" name="incomes"/>
                                <input type="hidden" value="<?php echo e($json_expenses); ?>" name="expenses"/>
                                <button type="submit" class="btn btn-primary"><i
                                    class="bi bi-printer"></i>Print</button>
                            </form>

                          </div>

                    </div>
                    <form action="<?php echo e(route('report.filter')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row mt-4">
                            <div class="col-md-2">
                                <label>Start date</label>
                                <input type="date" name="start_date" class="form-control">
                            </div>
                            <div class="col-md-2">
                                <label>End date</label>
                                <input type="date" name="end_date" class="form-control">
                            </div>
                            <div class="col-md-2">
                                <label>Type Of income</label>
                                <select name="income_type" class="form-control">
                                    <option disabled selected>--- select Income Type ---</option>
                                    <?php $__currentLoopData = $income_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($income_type->id); ?>">
                                            <?php echo e($income_type->income_type); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label>Type Of Expense</label>
                                <select name="expense_type" class="form-control">
                                    <option disabled selected>--- select expense Type ---</option>
                                    <?php $__currentLoopData = $expense_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($expense_type->id); ?>">
                                            <?php echo e($expense_type->expense_type); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-primary mt-4">Generate</button>
                            </div>
                        </div>
                    </form>
                    <div class="row">

                        <div class="col-md-6 p-5">
                            <h5 class="text-primary">All Incomes</h5>
                            <table class="table mt-3">
                                <thead style="background-color: #bbd0d750; color: #008ad3;">
                                    <th class="tab-font">Date</th>
                                    <th class="tab-font">Income Type</th>
                                    <th class="tab-font">Income</th>
                                    <th class="tab-font">Comment</th>

                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($income?->total > 0): ?>
                                    <?php $__currentLoopData = $income?->incomes_per_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="tab-font"><?php echo e($type?->date); ?></td>
                                        <td class="tab-font"><?php echo e($income?->type); ?></td>
                                        <td class="tab-font"><?php echo e(number_format($type?->income)); ?></td>
                                        <td class="tab-font"><?php echo e($type?->comment); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr class="bg-info">
                                    <td >Sub Total:</td>
                                    <td></td>
                                    <td><b><?php echo e(number_format($income?->total)); ?></b></td>
                                    <td></td>
                                </tr>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td >Total:</td>
                                        <td></td>
                                        <td><h4><?php echo e(number_format($all_incomes)); ?></h4></td>
                                        <td></td>
                                    </tr>
                                    
                                </tbody>
                            </table>
                        </div>

                        <div class="col-md-6 p-5">
                            <h5 class="text-primary">All Expenses</h5>
                            <table class="table mt-3">
                                <thead style="background-color: #bbd0d750; color: #008ad3;">
                                    <th class="tab-font">Date</th>
                                    <th class="tab-font">Expense Type</th>
                                    <th class="tab-font">Expense</th>
                                    <th class="tab-font">Comment</th>

                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($expense->total > 0): ?>
                                    <?php $__currentLoopData = $expense->expenses_per_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="tab-font"><?php echo e($type?->date); ?></td>
                                        <td class="tab-font"><?php echo e($expense?->type); ?></td>
                                        <td class="tab-font"><?php echo e(number_format($type?->expense)); ?></td>
                                        <td class="tab-font"><?php echo e($type?->comment); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr class="bg-info">
                                    <td>Sub Total: </td>
                                    <td></td>
                                    <td><b><?php echo e(number_format($expense->total)); ?></b></td>
                                    <td></td>
                                </tr>
                                    <?php endif; ?>  
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td >Total:</td>
                                        <td></td>
                                        <td><h4><?php echo e(number_format($all_expense)); ?></h4></td>
                                        <td></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>





                </div>

            </div>

        </div>

    </div>

    </div>

    </div>
    <!-- Optional JavaScript; choose one of the two! -->
    <script src="js/bootstrap.bundle.min.js"></script>
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->

</body>

</html>
<?php /**PATH /Users/projectcode/Sites/churchsystem/resources/views/reports/index.blade.php ENDPATH**/ ?>