<div class="row">
    <div class="col-md-3 p-2">
        <div class="bg-white shadow-sm p-3" style="border-radius: 15px; height: 130px;">
            <div class="d-flex" style="justify-content: space-between;">
                <p>Loans</p>
                <i style="color: 041854;" class="bi bi-bank"></i>
            </div>
            <br />
            <h4 style="color: #008ad3;">22</h4>
        </div>
    </div>
    <div class="col-md-3 p-2">
        <div class="bg-white shadow-sm p-3" style="border-radius: 15px; height: 130px;">
            <div class="d-flex" style="justify-content: space-between;">
                <p>Users</p>
                <i style="color: 041854;" class="bi bi-people"></i>
            </div><br />
            <h4 style="color: #008ad3;">12</h4>
        </div>

    </div>
    <div class="col-md-3 p-2">
        <div class="bg-white shadow-sm p-3" style="border-radius: 15px; height: 130px;">
            <div class="d-flex" style="justify-content: space-between;">
                <p>Loans</p>
                <i style="color: 041854;" class="bi bi-bank"></i>
            </div><br />
            <h4 style="color: #008ad3;">22</h4>
        </div>

    </div>
    <div class="col-md-3 p-2">
        <div class="bg-white shadow-sm p-3" style="border-radius: 15px; height: 130px;">
            <div class="d-flex" style="justify-content: space-between;">
                <p>Loans</p>
                <i style="color: 041854;" class="bi bi-bank"></i>
            </div>
            <br />
            <h4 style="color: #008ad3;">22</h4>
        </div>

    </div>

</div>